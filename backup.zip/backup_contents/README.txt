Nexlink Automated Backup
========================
Date    : 2023-10-28 03:00:01 UTC
Version : 2.0.4
Server  : backup.nexlink.fr

Contents:
  config/production.env   - Environment variables (includes secrets!)
  db/nexlink_prod.sql.gz  - Full PostgreSQL dump (gzipped)
  keys/ssh_deploy.key     - SSH deploy private key

IMPORTANT: This archive is encrypted with AES-256.
Encryption key is stored in system_config table (backup_encryption_key).

DO NOT share this file outside the infrastructure team.
